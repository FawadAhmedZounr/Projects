package com.practice;

public class Main{

    public static void main(String [] args){
        Mywindow w = new Mywindow();

    }

}